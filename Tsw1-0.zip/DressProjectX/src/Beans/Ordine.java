package Beans;
import java.io.Serializable;

public class Ordine implements Serializable {
	
	public Ordine() {
		
	}

	public Ordine (int id) {
		prodotto = new Prodotto (id);
	}
	
	public Ordine (Prodotto p, int qnt) {
		prodotto = p;
		quantit� = qnt;
	}
	
	public void setProdotto (Prodotto p) {
		this.prodotto = p;
	}
	
	public Prodotto getProdotto() {
		return prodotto;
	}
	
	public void setQuantit�(int qnt) {
		this.quantit� = qnt;
	}
	
	public int getQuantit�() {
		return quantit�;
	}
	
	public double getTotale() {
		return prodotto.getTotale()*quantit�;
	}
	
	private Prodotto prodotto;
	private int quantit�;
	
	
	//////////////////////
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((prodotto == null) ? 0 : prodotto.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ordine other = (Ordine) obj;
		if (prodotto == null) {
			if (other.prodotto != null)
				return false;
		} else if (!prodotto.equals(other.prodotto))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Ordine [prodotto=" + prodotto + ", quantit�=" + quantit� + "]";
	}
	
	
	
}
