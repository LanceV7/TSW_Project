package Beans;
import java.io.Serializable;
public class Indirizzo implements Serializable {
	
	
	public void setNazione(String nazione) {
		this.nazione = nazione;
	}

	public String getNazione() {
		return nazione;
	}
	
	
	public void setCitt�(String citt�) {
		this.citt� = citt�;
	}
	
	public String getCitt�() {
		return citt�;
	}
	
	
	public void setVia(String via) {
		this.via = via;
	}
	
	public String getVia() {
		return via;
	}
	
	public void setnCv(int nCv) {
		this.nCv = nCv;
	}
	
	public int getnCv() {
		return nCv;
	}
	
	public void setCAP(int CAP) {
		this.CAP = CAP;
	}
	
	public int getCAP() {
		return CAP;
	}
	
	
	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public int getCodice() {
		return codice;
	}

	public void setCodice(int codice) {
		this.codice = codice;
	}

	@Override
	public String toString() {
		return "Indirizzo [nazione=" + nazione + ", citt�=" + citt� + ", via=" + via + ", nCv=" + nCv + ", CAP=" + CAP
				+ "]";
	}


	private static final long serialVersionUID = -2258144367105250080L;
	private String nazione;
	private String citt�;
	private String via;
	private String provincia;
	private int codice;
	private int nCv;
	private int CAP;
}
