package Beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class Prodotto implements Serializable{

	public Prodotto() {
		
	}
	
	public Prodotto(int id) {
		idProdotto = id;
	}
	
	public Prodotto(String nome, String descrizione, double sconto,String genere,String taglia, String categoria,String url, String brand, String colore, double prezzo, int quantit�) {
		this.nomePr = nome;
		this.descrizione = descrizione;
		this.brand = brand;
		this.categoria = categoria;
		this.colore = colore;
		this.quantit� = quantit�;
		this.prezzo = prezzo;
		this.foto = url;
		this.taglia = taglia;
		this.genere = genere;
		this.sconto = sconto;
	}
	
	
	public String getTaglia() {
		return taglia;
	}

	public void setTaglia(String taglia) {
		this.taglia = taglia;
	}

	public void setIdProdotto(int idProdotto) {
		this.idProdotto = idProdotto;
	}
	
	public int getIdProdotto() {
		return idProdotto;
	}
	
	public void setNomePr(String nome) {
		this.nomePr = nome;
	}
	
	public String getNomePr() {
		return nomePr;
	}
	
	
	
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	
	public String getDescrizione() {
		return descrizione;
	}
	
	public void setGenere(String genere) {
		this.genere = genere;
	}
	
	public String getGenere() {
		return genere;
	}
	
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	
	public String getCategoria() {
		return categoria;
	}
	
	public void setColore(String colore) {
		this.colore = colore;
	}
	
	public String getColore() {
		return colore;
	}
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public String getBrand() {
		return brand;
	}
	
	
	public void setFoto(String foto) {
		this.foto = foto;
	}
	
	public String getFoto() {
		return foto;
	}
	
	public void setQuantit�(int qtn) {
		this.quantit� = qtn;
	}
	
	public int getQuantit�() {
		return quantit�;
	}
	
	public double getPrezzo() {
		return prezzo;
	}
	
	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}
	public double getSconto() {
		return sconto;
	}

	public void setSconto(double sconto) {
		this.sconto = sconto;
	}

	
	
	
	/*----------------*/
	
	

	public double getTotale () {
		return quantit� * prezzo;
	}
	
	public boolean isinDiscount() {
		return sconto > 0;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idProdotto;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Prodotto other = (Prodotto) obj;
		if (idProdotto != other.idProdotto)
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Prodotto [idProdotto=" + idProdotto + ", nomePr=" + nomePr + ", descrizione=" + descrizione
				+ ", genere=" + genere + ", colore=" + colore + ", brand=" + brand + ", foto=" + foto + ", categoria="
				+ categoria + ", quantit�=" + quantit� + ", prezzo=" + prezzo + "]";
	}

	private BigDecimal setDecimal (double d) {
		return new BigDecimal (d).setScale(2, RoundingMode.HALF_EVEN);
	}
	
	private int idProdotto;
	private String nomePr;
	private String descrizione;
	private String genere;
	private String colore;
	private String brand;
	private String foto;
	private String categoria;
	private int quantit�;
	private double prezzo;
	private String taglia;
	private double sconto;
}
