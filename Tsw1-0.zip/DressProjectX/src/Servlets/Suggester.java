package Servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import Beans.Prodotto;
import Models.ProdottoModel;
import Models.ProdottoModelDM;
import Models.ProdottoModelDS;

public class Suggester extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
    static Gson parser;
	static ProdottoModel model;
    /**
     * @see HttpServlet#HttpServlet()
     */
	@Override
	public void init() {
		if (new java.util.Random().nextBoolean())
			model= new ProdottoModelDM();
		else
			model= new ProdottoModelDS();
		
		parser = new GsonBuilder().registerTypeAdapter(Prodotto.class, new json.JsonBuilderProd()).create();
	}

	@Override
	public void service(ServletRequest request, ServletResponse response)
	throws ServletException, IOException {
		// recupero il tipo di categoria cercata dai parametri della richiesta
		String search = request.getParameter("srch");

		// recupero i feed corrispondenti dal database (implementato come Java Bean)
		
		List<Prodotto> list;
		try {
			list = model.doRetrieveBySearch(search, true);
			response.getWriter().write(parser.toJson(list));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
