package Servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

@WebServlet ("/Consumercatalogo")

public class ConsumerCatalog extends CatalogoServlet {

	private static final long serialVersionUID = -5451809842254823660L;

	public void init(javax.servlet.ServletConfig config) throws ServletException {
		super.init(config);

		URL = "Catalogo.jsp";
		numbEl = 20;
	}
	
}
