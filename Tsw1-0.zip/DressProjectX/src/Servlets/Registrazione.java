package Servlets;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Beans.Registrato;
import Models.RegisteredModel;
import Models.RegisteredDS;
import Models.RegisteredDM;

@WebServlet("/Registrazione")

public class Registrazione extends HttpServlet {
	private static final long serialVersionUID = 1L;

	static boolean isDataSource = true;
	static RegisteredModel model;
	static
	{
		if (isDataSource) {
			model = new RegisteredDS();
		} else {
			model = new RegisteredDM();
		}
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		String page = new String();
			
		Registrato user = new Registrato();
		user.setCognome(request.getParameter("Cognome"));
		user.setLogin(request.getParameter("email"));
		user.setName(request.getParameter("Nome"));
		user.setPassword(request.getParameter("password"));
		
		try {
			if (!model.doesExist(user)) {
				model.registration(user);
				page = "index.jsp";
			}
		} catch (java.sql.SQLIntegrityConstraintViolationException e) {
			// TODO: handle exception
			request.setAttribute("error", true);
			getServletContext().getRequestDispatcher(response.encodeURL("/registration.jsp")).forward(request, response);
			return;
		} 
		catch (SQLException e) {
			page = "error.jsp";
			e.printStackTrace();
		}
		
		response.sendRedirect(page);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}


