package Models;

import java.sql.Connection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import Beans.Fattura;
import Beans.Ordine;
import Beans.Prodotto;
import Beans.Registrato;;

public abstract class FatturaModel {

	private void setOrder (ResultSet rs, Ordine bean) throws SQLException{
		//fattura, prodotto, prezzoAp, quantita
		Prodotto item = new Prodotto ();
		
		item.setIdProdotto(rs.getInt("codice"));
		item.setNomePr(rs.getString("nome"));
		item.setCategoria(rs.getString("categoria"));
		item.setDescrizione(rs.getString("descrizione"));
		item.setBrand(rs.getString("brand"));
		item.setFoto(rs.getString("foto"));
		item.setTaglia(rs.getString("taglia"));
		item.setGenere(rs.getString("genere"));
		item.setPrezzo(rs.getInt("prezzo"));
		
		bean.setProdotto(item);
		bean.setQuantit�(rs.getInt("qty"));
	}
	
	//codiceFattura, registrato, dataFattura, Indirizzo
	//fattura, prodotto, prezzoAp, quantita, ivaAp, scontoAp
	
	public void doSave (Fattura f) throws Exception {

		Connection connection = null;
		PreparedStatement preparedStatement = null, insert = null;
		java.util.Date da = new java.util.Date();

		try {
			connection = getConnection();
			if(updateQtyProducts (f.getProdotti(), connection)) {
				preparedStatement = connection.prepareStatement(newFattura, java.sql.Statement.RETURN_GENERATED_KEYS);
	
				preparedStatement.setString(1, f.getUser().getLogin());
				preparedStatement.setDate(2, new java.sql.Date(da.getTime()));
				preparedStatement.setInt(3, f.getSpedizione().getCodice());
				preparedStatement.executeUpdate();
		
				ResultSet rs = preparedStatement.getGeneratedKeys();
			
				if (rs.next()) {
					f.setCod(rs.getInt(1));
					java.util.List<Ordine> list = f.getProdotti();
				
					for (Ordine o : list) {
						Prodotto bean = o.getProdotto();
						insert = connection.prepareStatement(insertOrder);
						insert.setInt(1, f.getCod());
						insert.setInt(2, bean.getIdProdotto());
						insert.setDouble(3, bean.getPrezzo());
						insert.setInt(4, o.getQuantit�());
						
						insert.executeUpdate();
					}
					
				}
			}else throw new Exception();
			
		} finally {
			try {
				if (preparedStatement != null || insert != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					closeConnection(connection);
			}
		}
	}
	
	private boolean updateQtyProducts(List<Ordine> prodotti, Connection connection) throws java.sql.SQLException {
		PreparedStatement preparedStatement = null;
		String updateProd = "UPDATE Prodotto SET Quantit� = Quantit� - ? where IdProdotto = ?";
		int cont = 0;
		try {

			for (Ordine o : prodotti) {
				
				Prodotto bean = o.getProdotto();
				preparedStatement = connection.prepareStatement(updateProd);
				preparedStatement.setInt(1, o.getQuantit�());
				preparedStatement.setInt(2, bean.getIdProdotto());
			
				preparedStatement.executeUpdate();
				cont++;
			}
			
		} catch (SQLException e) {
			String updateBack = "UPDATE Prodotto SET Quantit� = Quantit� + ? where IdProdotto = ?";
			for (int i = 0; i < cont; i++) {
				Ordine o = prodotti.get(i);
				Prodotto bean = o.getProdotto();
				preparedStatement = connection.prepareStatement(updateBack);
				preparedStatement.setInt(1, o.getQuantit�());
				preparedStatement.setInt(2, bean.getQuantit�());
				
				preparedStatement.executeUpdate();
			}
			if (preparedStatement != null)
				preparedStatement.close();
			return false;
		}
		return true;
	}

	public boolean hasPurchased (Beans.Prodotto product, Registrato e) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		String sql= "select * from Ordine join Fattura on Fattura = codiceFattura where registrato = ? and Prodotto = ?";
		
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, e.getLogin());
			preparedStatement.setInt(2, product.getIdProdotto());
			
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				return true;
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					closeConnection(connection);
			}
		}
		return false;
	}

	public java.util.List<Ordine> retrieveOrders (Registrato e, java.util.Date date, java.util.Date date2) throws java.sql.SQLException {
		Connection connection = null;
		SimpleDateFormat s = new SimpleDateFormat ("yyyy-MM-dd");
		String da = date != null ? s.format(date) : null;
		String a = date2 != null ? s.format(date2) : null;
		PreparedStatement preparedStatement = null;
		String selectSQL = da != null && a != null ? retrieveOrders + " AND dataFattura BETWEEN "+da +" AND " +a : da == null && a == null ? retrieveOrders: da == null && a!= null ? retrieveOrders +" AND dataFattura < " +a : retrieveOrders +" AND dataFattura > " +da;

		java.util.ArrayList<Ordine> products = new java.util.ArrayList<Ordine>();

		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(selectSQL + " ORDER BY Fattura");
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Ordine bean = new Ordine();
				
				setOrder(rs, bean);
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					closeConnection(connection);
			}
		}
		return products;
	}
	
	//"SELECT FROM * " +ORDER_TABLE +" WHERE fattura = ?";
	private java.util.List<Ordine> retrieveInvoiceOrders (int fattura, Connection connection) throws java.sql.SQLException {
		PreparedStatement preparedStatement = null;
		java.util.List<Ordine> list = new java.util.ArrayList<Ordine>();
		
		preparedStatement = connection.prepareStatement(retrieveInvoiceorders);
		preparedStatement.setInt(1, fattura);
		
		ResultSet rs = preparedStatement.executeQuery();
		
		while (rs.next()) {
			Ordine o = new Ordine ();
			
			setOrder(rs, o);
			list.add(o);
		}
		
		return list;
	}
	
	public Fattura retrieveInvoice (Registrato user, int code) throws java.sql.SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		Fattura f = new Fattura ();
		
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(retrieveInvoice);
			preparedStatement.setString(1, user.getLogin());
			preparedStatement.setInt(2, code);
			
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				java.util.GregorianCalendar cl = new java.util.GregorianCalendar();
				cl.setTime(rs.getDate("dataFattura"));
				
				f.setCod(rs.getInt("codiceFattura"));
				f.setProdotti(this.retrieveInvoiceOrders(f.getCod(), connection));
				f.setUser(new Models.RegisteredDM().doRetrieveByKey(user.getLogin()));
				f.setSpedizione(new IndirizzoDS().doRetrieve(rs.getInt("Indirizzo")));
				f.setDate(cl);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					closeConnection(connection);
			}
		}

		return f;
	}
	
	public java.util.List<Fattura> retrieveInvoices (Registrato e, java.util.Date date, java.util.Date date2) throws java.sql.SQLException {
		Connection connection = null;

		PreparedStatement preparedStatement = null;
		String selectSQL = retrieveAllInvoices + " WHERE registrato = ?";
		
		java.util.List<Fattura> list = new java.util.ArrayList<Fattura> ();

		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			
			if (date != null && date2 != null) {
				selectSQL = selectSQL + " AND dataFattura BETWEEN ? AND ?";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, e.getLogin());
				preparedStatement.setDate(2, new java.sql.Date(date.getTime()));
				preparedStatement.setDate(3, new java.sql.Date(date2.getTime()));
			} else if (date != null && date2 == null) {
				selectSQL = selectSQL + " AND dataFattura > ?";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, e.getLogin());
				preparedStatement.setDate(2, new java.sql.Date(date.getTime()));
			} else if (date == null && date2 != null) {
				selectSQL = selectSQL + " AND dataFattura < ?";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, e.getLogin());
				preparedStatement.setDate(2, new java.sql.Date(date2.getTime()));
			} else {
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, e.getLogin());
			}
				
			
			
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Fattura f = new Fattura();
				
				java.util.GregorianCalendar cl = new java.util.GregorianCalendar();
				cl.setTime(rs.getDate("dataFattura"));
				
				f.setCod(rs.getInt("codiceFattura"));
				f.setProdotti(this.retrieveInvoiceOrders(f.getCod(), connection));
				f.setSpedizione(new IndirizzoDS().doRetrieve(rs.getInt("Indirizzo")));
				f.setDate(cl);
				f.setUser(e);
				
				list.add(f);
			}
		
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					closeConnection(connection);
			}
		}
		return list;
	}
	
	public List<Fattura> retrieveInvoices(java.util.Date date, java.util.Date date2) throws SQLException {
		// TODO Auto-generated method stub
		Connection connection = null;

		PreparedStatement preparedStatement = null; 
		String selectSQL = retrieveAllInvoicesUsers;
		java.util.List<Fattura> list = new java.util.ArrayList<Fattura> ();

		try {
			connection = getConnection();
			
			if (date != null && date2 != null) {
				selectSQL = selectSQL + " WHERE dataFattura BETWEEN ? AND ?";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setDate(1, new java.sql.Date(date.getTime()));
				preparedStatement.setDate(2, new java.sql.Date(date2.getTime()));
			} else if (date != null && date2 == null) {
				selectSQL = selectSQL + " WHERE dataFattura > ?";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setDate(1, new java.sql.Date(date.getTime()));
			} else if (date == null && date2 != null) {
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setDate(1, new java.sql.Date(date2.getTime()));
			} else 
				preparedStatement = connection.prepareStatement(selectSQL);
			
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Fattura f = new Fattura();
				Registrato bean = new Registrato ();
				java.util.GregorianCalendar cl = new java.util.GregorianCalendar();
				cl.setTime(rs.getDate("dataFattura"));

				RegisteredModel.setBean(rs, bean);
				f.setCod(rs.getInt("codiceFattura"));
				f.setProdotti(retrieveInvoiceOrders(f.getCod(), connection));
				f.setSpedizione(new IndirizzoDS().doRetrieve(rs.getInt("Indirizzo")));
				f.setDate(cl);
				f.setUser(bean);
				
				list.add(f);
			}
	
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					closeConnection(connection);
			}
		}
		return list;
	}
	
	public abstract void closeConnection(Connection connector) throws SQLException;
	public abstract Connection getConnection () throws SQLException;
	
	private static final String ORDER_TABLE = "Ordine";
	private static final String PROD_TABLE = "Prodotto";
	private static final String FATT_TABLE = "Fattura";
	private static final String newFattura = "INSERT INTO " +FATT_TABLE +" (registrato, dataFattura, Indirizzo) VALUES (?,?,?)";
	private static final String retrieveInvoice = "SELECT * FROM " +FATT_TABLE +" WHERE registrato = ? AND codiceFattura = ?";
	private static final String retrieveInvoiceorders = "SELECT * FROM " +ORDER_TABLE +" JOIN " +PROD_TABLE + " ON IdProdotto = Prodotto  WHERE Fattura = ?";
	private static final String retrieveAllInvoices = "SELECT * FROM " +FATT_TABLE;
	private static final String retrieveAllInvoicesUsers = "SELECT * FROM " +FATT_TABLE +" JOIN " +RegisteredModel.TABLE + " ON loginA = registrato ";
	private static final String insertOrder = "INSERT INTO "+ORDER_TABLE+" VALUES (?, ?, ?, ?, ?, ?)";
	private static final String retrieveOrders = "SELECT * FROM "+ORDER_TABLE +" JOIN " +PROD_TABLE + " ON IdProdotto = Prodotto WHERE registrato = ?";
	
	
	
}
