package Models;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class RegisteredDM extends RegisteredModel {
	
	@Override
	public Connection getConnection() throws SQLException {
		// TODO Auto-generated method stub
		return DriverConnectionPool.getConnection();
	}

	@Override
	public void closeConnection(Connection connector) throws SQLException {
		// TODO Auto-generated method stub
		DriverConnectionPool.releaseConnection(connector);
	}

}
