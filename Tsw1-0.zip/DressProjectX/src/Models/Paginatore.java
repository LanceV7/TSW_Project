package Models;



public class Paginatore <E> {

	public Paginatore() {
		numEl = 8;
		page = 1;
	}
	
	public Paginatore(int numeroEl) {
		numEl = numeroEl;
		page = 1;
	}
	
	public Paginatore (int numeroEl, int page) {
		numEl = numeroEl;
		this.page = page;
	}
	
	public Pair Paginate (java.util.List<E> list) {
		java.util.List<E> pagedList = null;
		int start = numEl * (page - 1);
		int size = list.size();
		int maxPg = (size/numEl) + 1;
		
		if(size > start && size - start > numEl)
			pagedList = list.subList(start, start + numEl);
		else if(size > start && size - start <= numEl) 
			pagedList = list.subList(start, size);
			
		return new Pair (pagedList, maxPg);
	}
	
	public class Pair {
		public java.util.List<E> pagedList;
		public int maxPg;
		
		Pair (java.util.List<E> list, int max){
			maxPg = max;
			pagedList = list;
		}
	}
	
	private int page;
	private int numEl;
}
