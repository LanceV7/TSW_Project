package Models;

public class ProdottoModelDM extends ProdottoModel {
	@Override
	protected java.sql.Connection getConnection() throws java.sql.SQLException {
		// TODO Auto-generated method stub
		return DriverConnectionPool.getConnection();
	}

	@Override
	protected void closeConnection(java.sql.Connection connector) throws java.sql.SQLException {
		// TODO Auto-generated method stub
		DriverConnectionPool.releaseConnection(connector);
	}


}
