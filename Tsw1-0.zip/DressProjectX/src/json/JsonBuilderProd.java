package json;

import java.lang.reflect.Type;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;

import Beans.Prodotto;

public class JsonBuilderProd implements com.google.gson.JsonSerializer<Beans.Prodotto>{
	public JsonElement serialize(Prodotto o, Type arg1, JsonSerializationContext arg2) {
		// TODO Auto-generated method stub
		JsonObject obj = new JsonObject();
		
		String ctgy= o.getCategoria();
		String uomo="";
			if("0".equals(ctgy+uomo)){ uomo="T-shirt e Polo";}
			if("1".equals(ctgy+uomo)){ uomo="Camicie";}
			if("2".equals(ctgy+uomo)){ uomo="Maglie e Felpe";}
			if("3".equals(ctgy+uomo)){ uomo="Jeans";}
			if("4".equals(ctgy+uomo)){ uomo="Pantaloni";}
			if("5".equals(ctgy+uomo)){ uomo="Giacche";}
			if("6".equals(ctgy+uomo)){ uomo="Cappotti";}
			
		String donna="";
			if("0".equals(ctgy+donna)){donna="Vestito Intero";}
			if("1".equals(ctgy+donna)){donna="T-Shirt e Top";}
			if("2".equals(ctgy+donna)){ donna="Camicie";}
			if("3".equals(ctgy+donna)){ donna="Tute-Jumpsuit";}
			if("4".equals(ctgy+donna)){ donna="Abbigliamento Sportivo";}
			if("5".equals(ctgy+donna)){ donna="Felpe";}
			if("6".equals(ctgy+donna)){ donna="Jeans";}
			if("7".equals(ctgy+donna)){ donna="Pantaloni";}
			if("8".equals(ctgy+donna)){ donna="Gonne";}
			if("9".equals(ctgy+donna)){ donna="Giacche";}
			if("10".equals(ctgy+donna)){ donna="Cappotti";}
			
		
		obj.addProperty("IdProdotto", o.getIdProdotto());
		obj.addProperty("Nome", o.getNomePr());
		obj.addProperty("Genere", o.getGenere());
		obj.addProperty("Taglia", o.getTaglia());
		obj.addProperty("Colore", o.getColore());
		obj.addProperty("Foto", o.getFoto());
		obj.addProperty("Descrizione", o.getDescrizione());
		obj.addProperty("Prezzo", o.getTotale());
		obj.addProperty("Quantit�", o.getQuantit�());
		obj.addProperty("Brand", o.getBrand());
		obj.addProperty("category", uomo);
		obj.addProperty("category", donna);
		
		return obj;
	}

}
