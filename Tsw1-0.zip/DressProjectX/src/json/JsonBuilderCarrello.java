package json;
import java.lang.reflect.Type;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;

//com.google.gson.JsonSerializer.Beans.Carrello

public class JsonBuilderCarrello implements com.google.gson.JsonSerializer<Beans.Carrello>{

	public JsonElement serialize(Beans.Carrello carrello, Type arg1, JsonSerializationContext arg2) {
		// TODO Auto-generated method stub
		JsonObject obj = new JsonObject();
		
		
		
		obj.addProperty("tot", carrello.getTotal().toString());
		obj.addProperty("size", carrello.size());
		obj.add("list", new GsonBuilder().registerTypeAdapter(Beans.Ordine.class, new json.JsonBuilderOrdine()).create().toJsonTree(carrello.getOrdini()));
		
		return obj;
	}
	
}
