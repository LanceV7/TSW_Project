/**
 * 
 */
$(document).ready(function(){
		var i = 0;
		
		function isEmpty(a) {
			return a == null || a==NaN || a=="";
		}
		
		$("#submit").click(function () {
			var pg = $(".pageof").val();
			$.get("admincat", {pg : pg})
				.done (function (json) {
					$("tbody tr").remove();
					
					$.each(json, function () {
						
						var row = '<tr id ="'+this.id+'" class = "text-center">'
						+ '<td class="product-remove"><button class="removeX" style="background-image: url(\'img/x.png\')"></button></td>'
						+ '<td class="nome-prodotto"> <h4>Prodotto: '+this.nome+'<span></span></h4><button  class="button button2 submitter" type="submit">Modifica</button></td>'
						+ '<td><div id="img" style="background-image: url('+this.img+');"></div></td>'
						+ '<td role = "prezzo">'+this.prezzo+'&#8364;</td>'
						+ '<td role = "quantità">'+this.quantità+'</td>'
						+ '<td role = "brand">'+this.brand+'</td>'
						+ '<td role = "taglia">'+this.taglia+'%</td>'
						+ '<td role = "genere">'+this.genere+'</td>'
						+ '<td role = "colore">'+this.colore+'</td>'
						+ '<td role = "categoria">'+this.categoria+'</td>'
						+' </tr>';
						
						$("tbody").append(row);
					});
					
					$(".removeX").click(remove);
					$(".button").click(prova);
				})
				.fail (function () {
					alert("fail");
				});
		});
		
		//funzionante
		$(".removeX").click (remove);
		
		function remove () {
			var row = $(this).parents().filter("tr");
			var code = $(row).attr("id");
			
			$.post("ProdottoAdminControllo", {act: "delete", id : code})
				.done(function () {
					$(row).remove();
				})
				.fail(function () {
					alert("Non e' stato possibile rimuovere il prodotto");
				})
		}
		
  		$(".button").click(prova);
  		
  	
	});