/**
 * 
 */
$(document).ready(function() {
	
	$("#but1").click(function () {
		var nome = $("#nome").val();
		var prezzo = $("#prezzo").val();
		var quantità = $("#quantita").val();
		var brand = $("#brand").val();
		var url = $("#url").val();
		var colore = $("#colore").val();
		var genere = $("#genere").val();
		var taglia = $("#taglia").val();
		var categoria = $("#categoria").val();
		var des = $("#des").val();
		
		$.post("ProductAdminControl", {act: "inserisci", nome : nome, prezzo : prezzo, quantità : quantità, brand: brand, url : url,colore : colore, taglia : taglia, genere : genere, categoria : categoria, descrizione : des})
		.done(function(data){
			 $("#esito").append('<div id= "success5" class="alert success"><span class="closebtn">&times;</span><strong>Successo!</strong>Prodotto inserito correttamente</div>').hide().slideDown();
		})
		.fail(function() {
			 $("#esito").append('<div id= "alert5" class="alert"><span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span><strong>Errore!</strong> Errore durante l\'inserimento</div>').hide().slideDown();
		})
		.always(function () {
			$("#esito .closebtn").click(function () {
				$("#esito div").remove();
			})
		});
	});
});