package Servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Beans.Prodotto;
import Models.ProdottoModel;
import Models.ProdottoModelDM;
import Models.ProdottoModelDS;



public class IndiceServlet extends HttpServlet{
	
	static boolean isDataSource = true;
	static ProdottoModel model;
	
	static {
		if (isDataSource) {
			model = new ProdottoModelDS();
		} else {
			model = new ProdottoModelDM();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//index servlet deve caricare una lista di prodotti in sconto
		try {
			List<Prodotto> list = model.doRetrieveByDiscount(30, true);
			
			if (list.size()>10)
				request.setAttribute("list", list.subList(0, 10));
			else 
				request.setAttribute("list", list);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		getServletContext().getRequestDispatcher("/contentJSP/ProductCard.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
