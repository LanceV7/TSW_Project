package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Addebito")

public class Addebito extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public Addebito() {
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		Beans.Carrello cart = request.getSession().getAttribute("carrello") == null ? new Beans.Carrello() : (Beans.Carrello) request.getSession().getAttribute("carrello");
		
		if (cart.isEmpty()) response.setStatus(204);
		else if(request.getSession().getAttribute("user") != null) {
			request.getRequestDispatcher("AddressOperations?operation=0").include(request, response);
			request.getRequestDispatcher(response.encodeURL("Checkout.jsp")).forward(request, response);
		} else {
			request.getSession().setAttribute("wasPaying", true);
			response.sendRedirect (response.encodeURL("Login.jsp"));
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
