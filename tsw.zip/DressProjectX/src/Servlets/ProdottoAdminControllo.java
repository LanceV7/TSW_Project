package Servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.JsonObject;

import Beans.Prodotto;
import Models.ProdottoModel;
import Models.ProdottoModelDM;
import Models.ProdottoModelDS;

public class ProdottoAdminControllo {
private static final long serialVersionUID = 1000L;
    
	static boolean isDataSource = true;
	
	static ProdottoModel model;
	
	static {
		if (isDataSource) {
			model = new ProdottoModelDS();
		} else {
			model = new ProdottoModelDM();
		}
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Boolean isAdmin = (Boolean) request.getSession().getAttribute("isAdmin");
		String action = request.getParameter("act");
		
		try {
			if (action != null && (isAdmin == null ? false : isAdmin)) {
					if (action.equalsIgnoreCase("delete")) {
						int id = Integer.parseInt(request.getParameter("id"));
						model.doDelete(id);
					} else if (action.equalsIgnoreCase("insert")) {
						Prodotto bean = new Prodotto();
						
						//codice, nome, descrizione, prezzo, quantita, brand, foto, taglia, genere, categoria
						bean.setIdProdotto(Integer.parseInt(request.getParameter("CodiceProdotto")));
						bean.setNomePr(request.getParameter("name"));
						bean.setDescrizione(request.getParameter("descrizione"));
						bean.setBrand(request.getParameter("brand"));
						bean.setFoto(request.getParameter("url"));
						bean.setGenere(request.getParameter("genere")); 
						bean.setCategoria(request.getParameter("categoria"));
						bean.setQuantit�(Integer.parseInt(request.getParameter("quantit�")));
						bean.setPrezzo(Double.parseDouble(request.getParameter("prezzo")));
						bean.setSconto(Integer.parseInt(request.getParameter("sconto")));
						
						model.doSave(bean);
					} else if (action.equalsIgnoreCase("modify")) {
						
						Prodotto bean = new Prodotto();
						bean.setIdProdotto(Integer.parseInt(request.getParameter("CodiceProdotto")));
						bean.setPrezzo(Double.parseDouble(request.getParameter("prezzo")));
						bean.setQuantit�(Integer.parseInt(request.getParameter("quantit�")));
						bean.setSconto(Integer.parseInt(request.getParameter("sconto")));
						
						model.doUpdate(bean);
						
						if (request.getHeader("x-requested-with")!= null){
							response.setContentType("application/json");
							JsonObject obj = new JsonObject ();
							
							obj.addProperty("newPrice", bean.getPrezzo()+"&#8364;");
							obj.addProperty("newQty", bean.getQuantit�());
							obj.addProperty("newSconto", bean.getSconto() +"%");
							
							response.getWriter().write(new com.google.gson.Gson().toJson(obj));
						}
					}
				}
			}
			catch (SQLException e) {
				response.sendRedirect(response.encodeURL("error.jsp"));
				e.printStackTrace();
			}
			catch (java.lang.NumberFormatException e){
				e.printStackTrace();
				response.sendError(406);
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
