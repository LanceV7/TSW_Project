package Servlets;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AdminCatalogo")
public class AdminCatalogo  extends CatalogoServlet {
	private static final long serialVErsionUID = 1L;
	
	public void init(javax.servlet.ServletConfig config) throws ServletException{
		super.init(config);
		
		URL = "catalogoAdm.jsp";
		numbEl = 42;
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Boolean isAdmin = (Boolean) request.getSession().getAttribute("isAdmin");
		
		if(isAdmin == null ? false : isAdmin.booleanValue())
			
			super.doGet(request, response);
		else 
			response.sendRedirect("Login.jsp");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	

 }
