package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import Beans.Indirizzo;
import Models.IndirizzoModel;
import Models.IndirizzoDS;
import Models.IndirizzoDM;

@WebServlet("/IndirizzoOperazioni")
public class IndirizzoOperazioni extends HttpServlet {
	static boolean isDataSource = true;
	static IndirizzoModel model;

	static {
		if (isDataSource) {
			model = new IndirizzoDS();
		} else {
			model = new IndirizzoDM();
		}
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			int op = Integer.parseInt(request.getParameter("operation"));
			Beans.Registrato user = (Beans.Registrato) request.getSession().getAttribute("user");
			java.util.Map<Integer,Beans.Indirizzo> ad = (java.util.Map<Integer,Beans.Indirizzo>)request.getSession().getAttribute("addresses");
			if (op == 0 && user != null) {
				//operazione di visualizzazione
				request.getSession().setAttribute("addresses", model.doRetrieveAll(user.getLogin()));
			} else if (op == 1 && user != null) {
				//operazione di inserimento
				Indirizzo bean = new Indirizzo ();
				bean.setCAP(Integer.parseInt(request.getParameter("cap")));
				bean.setCitt�(request.getParameter("citta"));
				bean.setNazione(request.getParameter("Nazione"));
				bean.setnCv(Integer.parseInt(request.getParameter("ncv")));
				bean.setProvincia(request.getParameter("provincia"));
				bean.setVia(request.getParameter("via"));
				bean.setCodice(model.doSave(bean,user));
				
				
				if (ad != null) {
					ad.put(bean.getnCv(), bean);
					request.getSession().setAttribute("indirizzi", ad);
				}
				if (request.getHeader("x-requested-with") != null) {
					response.setContentType("application/json");
					response.getWriter().write(new Gson().toJson(bean));
				}
			} else if (op == 2 && user != null) {
				//operazione di modifica
				Indirizzo bean = new Indirizzo ();
				
				bean.setCAP(Integer.parseInt(request.getParameter("cap")));
				bean.setCitt�(request.getParameter("citta"));
				bean.setNazione(request.getParameter("nazione"));
				bean.setnCv(Integer.parseInt(request.getParameter("ncv")));
				bean.setVia(request.getParameter("via"));
				
				model.doModify(Integer.parseInt(request.getParameter("code")), bean);
			} else if (op == 3 && user != null) {
				//operazione di cancellazione
				model.doDelete(Integer.parseInt(request.getParameter("code")));
			} else if (op == 4 && user != null) {
				//operazione di verifica
				
			}
		} catch (java.sql.SQLException e) {
			e.printStackTrace();
			response.sendRedirect(response.encodeURL("error.jsp"));
		}
		catch (Exception e) {
			response.sendRedirect(response.encodeURL("error.jsp"));
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	
	
	private static final long serialVersionUID = 1L;
	
}
