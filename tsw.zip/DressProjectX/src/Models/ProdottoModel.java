package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Beans.Prodotto;

public abstract class ProdottoModel {
	
	public void setBean (ResultSet rs, Prodotto item) throws SQLException {
		item.setIdProdotto(rs.getInt("idProdotto"));
		item.setNomePr(rs.getString("Nome"));
		item.setBrand(rs.getString("Brand"));
		item.setFoto(rs.getString("Foto"));
		item.setCategoria(rs.getString("Categoria"));
		item.setDescrizione(rs.getString("Descrizione"));
		item.setColore(rs.getString("Colore"));
		item.setGenere(rs.getString("Genere"));
		item.setQuantit�(rs.getInt("Quantit�"));
		item.setPrezzo(rs.getDouble("Prezzo"));
		item.setSconto(rs.getDouble("Sconto"));
	}
	
	public void prepareInsertStatement (PreparedStatement preparedStatement, Prodotto item) throws SQLException {
		
		preparedStatement.setString(1, item.getNomePr());
		preparedStatement.setString(2, item.getDescrizione());
		preparedStatement.setDouble(3, item.getPrezzo());
		preparedStatement.setInt(4, item.getQuantit�());
		preparedStatement.setString(5, item.getFoto());
		preparedStatement.setString(6, item.getGenere());
		preparedStatement.setString(7, item.getCategoria());
		preparedStatement.setString(8, item.getColore());
		preparedStatement.setString(9, item.getBrand());
		preparedStatement.setDouble(10,item.getSconto());
	}
	
	private void prepareSQLlist (PreparedStatement statement, int [] codes) throws SQLException{
		int size = codes.length;
		for(int i=0; i<size; i++) {
			statement.setInt(i + 1, codes[i]);
		}
	}
	
	
	private String setSQLlistString (int size) {
		String SQLlist = selectAllSQL + "WHERE IdProdotto = ?";
		for (int i = 0; i<size - 1; i++)
		     SQLlist = SQLlist + "OR IdProdotto = ? ";	
		return SQLlist;
	}
	
public synchronized void doSave (Prodotto prodotto) throws SQLException{
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
			prepareInsertStatement(preparedStatement, prodotto);
			
			preparedStatement.executeUpdate();
			
			connection.commit();
		}finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
		}finally {
			if (connection != null)
				closeConnection(connection);
		}
	}
}		
	
public synchronized Prodotto doRetrieveBykey (int code, Boolean acquistabile) throws SQLException{
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		Prodotto bean = new Prodotto();
		
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, code);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next())
				setBean(rs,bean);
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				closeConnection(connection);
			}
		}
		return bean;
	}
	public synchronized boolean doDelete(int code) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int result = 0;

		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, code);

			result = preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					closeConnection(connection);
			}
		}
		return (result != 0);
	}
	

	public synchronized java.util.List<Prodotto> doRetrieveAll(Boolean acquistabile) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		java.util.ArrayList<Prodotto> products = new java.util.ArrayList<Prodotto>();
		String selectSQL = acquistabile == null ? selectAllSQL : selectAllSQL + " WHERE Acquistabile = ? ORDER BY Nome";
		
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setBoolean(1, acquistabile.booleanValue());
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Prodotto bean = new Prodotto();

				setBean(rs, bean);
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					closeConnection(connection);
			}
		}
		return products;
	}
	

	public synchronized java.util.List<Prodotto> doRetrieveByCategory(String categoria) throws SQLException {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		java.util.ArrayList<Prodotto> products = new java.util.ArrayList<Prodotto>();

		String selectSQL = categorySQL + order;

		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, categoria);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Prodotto bean = new Prodotto();			
				setBean(rs, bean);
				products.add(bean);

			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					closeConnection(connection);
			}
		}
		return products;
	}

	public synchronized java.util.List<Prodotto> doRetrieveBySearch(String search, Boolean acquistabile) throws SQLException {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		java.util.ArrayList<Prodotto> products = new java.util.ArrayList<Prodotto>();
		String acquist = acquistabile == null ? "" : " AND Acquistabile = ?"; 
		String selectSQL = searchSQL +acquist + order;
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, "%"+search+"%");
			preparedStatement.setString(2, "%"+search+"%");
			if (acquistabile) preparedStatement.setBoolean(3, acquistabile);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Prodotto bean = new Prodotto();

				setBean(rs, bean);
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					closeConnection(connection);
			}
		}
		return products;
	}
	
	public synchronized List<Prodotto> doRetrieveByDiscount(double amount, Boolean acquista) throws Exception {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		List<Prodotto> list = new ArrayList<Prodotto>();
		String selectSQL = acquista == null ? selectDiscountSQL : selectDiscountSQL + " AND Acquistabile = ?";
		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setDouble(1, amount);
			if (acquista) preparedStatement.setBoolean(2, acquista);

			ResultSet result = preparedStatement.executeQuery();

			while (result.next())
			{	
				int qty = result.getInt("quantita");
				
				if (qty > 0)
				{
					Prodotto bean = new Prodotto();
					setBean(result, bean);
					list.add(bean);
				}
			}
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					closeConnection(connection);
			}
		}
		return list;
	}
	
	public synchronized boolean doUpdate(Prodotto item) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		//prezzo = ?, quantita = ?, iva = ?, sconto = ?
		int result = 0;

		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(updateSQL);
			
			preparedStatement.setDouble(1, item.getPrezzo());
			preparedStatement.setInt(2, item.getQuantit�());		
			preparedStatement.setInt(3, item.getIdProdotto());
			
			result = preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					closeConnection(connection);
			}
		}
		return (result != 0);
	}

	public synchronized List<Prodotto> doRetrieveList(int[] codes, Boolean acquista) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String a = acquista == null ? "" :  " AND Acquistabile = ?";
		String query = setSQLlistString(codes.length) +a;
		java.util.List <Prodotto> list = new java.util.ArrayList <Prodotto> ();

		try {
			connection = getConnection();
			preparedStatement = connection.prepareStatement(query);
			prepareSQLlist(preparedStatement, codes);
			if (acquista) preparedStatement.setBoolean(codes.length + 1, acquista);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Prodotto bean = new Prodotto ();
				setBean(rs, bean);
				list.add(bean);
			}
			
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					closeConnection(connection);
			}
		}
		return list;
	}

	
	protected abstract void closeConnection(Connection connector) throws SQLException;
	protected abstract Connection getConnection () throws SQLException;

	protected static final String TABLE_NAME = "prodotto";
	protected static final String selectSQL = "SELECT * FROM " +TABLE_NAME + " WHERE IdProdotto = ?";
	protected static final String selectAllSQL = "SELECT * FROM " + TABLE_NAME;
	protected static final String selectDiscountSQL = "SELECT * FROM DressYouNow.Prodotto WHERE Sconto >= ?";
	protected static final String deleteSQL = "UPDATE "+TABLE_NAME+" SET Acquistabile = false WHERE IdProdotto = ?";
	protected static final String insertSQL = "INSERT INTO " + TABLE_NAME
			+ "( Nome, Descrizione, Genere, Quantit�, Categoria, Prezzo,  Taglia, Brand, Colore,  Foto, Sconto)"
			+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	protected static final String updateSQL = "UPDATE Prodotto SET "
			+ "Prezzo = ?, Quantit� = ?, Sconto = ?"
			+ " WHERE IdProdotto = ?";
	protected static final String searchSQL = "SELECT * FROM "+TABLE_NAME+ " WHERE Nome LIKE ? or Descrizione LIKE ?";
	protected static final String categorySQL = "SELECT * FROM "+TABLE_NAME+ " WHERE Genere = ? AND Acquistabile = 1";
	protected static final String order = " ORDER BY Nome";

}
