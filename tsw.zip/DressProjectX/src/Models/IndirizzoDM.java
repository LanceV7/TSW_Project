package Models;


import java.sql.Connection;
import java.sql.SQLException;

public class IndirizzoDM extends IndirizzoModel {
	
	public Connection getConnection() throws SQLException {
		// TODO Auto-generated method stub
		return DriverConnectionPool.getConnection();
	}

	public void closeConnection(Connection connector) throws SQLException {
		// TODO Auto-generated method stub
		DriverConnectionPool.releaseConnection(connector);
	}

}
