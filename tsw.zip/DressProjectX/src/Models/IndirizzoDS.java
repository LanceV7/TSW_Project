package Models;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class IndirizzoDS extends IndirizzoModel {

	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");
			
			ds = (DataSource) envCtx.lookup("jdbc/DressYouNow");
		
		}catch(NamingException e) {
			System.out.println("Errore: " + e.getMessage());
		}
	}
	
	public void closeConnection(java.sql.Connection connector) throws java.sql.SQLException {
		// TODO Auto-generated method stub
		connector.close();
	}

	public java.sql.Connection getConnection() throws java.sql.SQLException {
		// TODO Auto-generated method stub
		return ds.getConnection();
	}
	
	private static DataSource ds;
}
