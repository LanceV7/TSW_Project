package Models;

import java.sql.Connection;
import java.sql.SQLException;

public class FatturaModelDM extends FatturaModel {

	
	public Connection getConnection() throws SQLException {
		// TODO Auto-generated method stub
		return DriverConnectionPool.getConnection();
	}

	@Override
	public void closeConnection(Connection connector) throws SQLException {
		// TODO Auto-generated method stub
		DriverConnectionPool.releaseConnection(connector);
	}
}
