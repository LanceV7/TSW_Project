package json;

import java.lang.reflect.Type;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;

import Beans.Ordine;
import Beans.Prodotto;

public class JsonBuilderOrdine  implements com.google.gson.JsonSerializer<Beans.Ordine>{
	public JsonElement serialize(Ordine order, Type arg1, JsonSerializationContext arg2) {
		JsonObject obj = new JsonObject();
		
		obj.addProperty("totOrdine", order.getTotale());
		obj.add("order", new GsonBuilder().registerTypeAdapter(Prodotto.class, new json.JsonBuilderProd()).create().toJsonTree(order.getProdotto()));
		
		return obj;
	}
}
