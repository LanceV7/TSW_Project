package Beans;

public class Admin extends UserBean{
	private static final long serialVersionUID = 8657978459991828019L;   
}
