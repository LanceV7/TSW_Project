package Beans;

public class Fattura  implements java.io.Serializable{
	
	
	
	public java.util.List<Beans.Ordine> getProdotti() {
		return prodotti;
	}
	public void setProdotti(java.util.List<Beans.Ordine> prodotti) {
		this.prodotti = prodotti;
	}
	public int getCod() {
		return cod;
	}
	public void setCod(int cod) {
		this.cod = cod;
	}
	public java.util.GregorianCalendar getDate() {
		return date;
	}
	public void setDate(java.util.GregorianCalendar date) {
		this.date = date;
	}
	public Beans.Indirizzo getSpedizione() {
		return spedizione;
	}
	public void setSpedizione(Beans.Indirizzo spedizione) {
		this.spedizione = spedizione;
	}
	public Registrato getUser() {
		return user;
	}
	public void setUser(Registrato user) {
		this.user = user;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public int size() {
		return prodotti.size();
	}
	
	public double getTotale() {
		double totale = 0;
		java.util.List<Ordine> list = prodotti;
		
		for (Ordine o: list) {
			Beans.Prodotto item = o.getProdotto();
			
			totale = totale + o.getQuantit�() * (item.getTotale());
			}
		return totale;
	}
	
	
	
	@Override
	public String toString() {
		return "Fattura = [prodotti=" + prodotti + ", cod=" + cod + ", date=" + date + ", spedizione=" + spedizione
				+ ", user=" + user + "]";
	}



	private static final long serialVersionUID = -7048837643544538726L;
	private java.util.List <Beans.Ordine> prodotti;
	private int cod;
	private java.util.GregorianCalendar date;
	private Beans.Indirizzo spedizione;
	private Registrato user;

}
