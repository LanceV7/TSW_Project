package Beans;

import java.io.Serializable;
import java.math.RoundingMode;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class Carrello implements Serializable {

	public Carrello() {
		prodotti = new HashMap<Integer, Ordine>();
	}
	
	public void addOrdine(Ordine o) {
		prodotti.put(o.getProdotto().getIdProdotto(), o);
	}
	
	public void deleteOrdine(int id) {
		prodotti.remove(id);
	}
	
	public Ordine getOrdine(int id) {
		return prodotti.get(id);
	}
	
	public java.util.ArrayList<Ordine> getOrdini() {
		return new java.util.ArrayList <Ordine>(prodotti.values());
	}
	
	public int [] getCodes () {
		java.util.Set<Integer> set = prodotti.keySet();
		return set.stream().mapToInt(Integer::intValue).toArray();
	}
	
	public java.math.BigDecimal getTotal () {
		double total = 0;
		Collection<Ordine> list = prodotti.values();
		
		for (Ordine o : list) {
			Beans.Prodotto item = o.getProdotto();
			
			total = total + o.getQuantit�();
		}
		
		return new java.math.BigDecimal(total).setScale(2, RoundingMode.HALF_EVEN);
	}
	
	
	public int size () {
		return prodotti.size();
	}

	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return prodotti.isEmpty();
	}
	
	
	private static final long serialVersionUID = 572202513877133735L;
	private Map<Integer, Ordine> prodotti;
}
